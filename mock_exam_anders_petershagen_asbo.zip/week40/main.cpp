#include "tasks.h"

int main() {
	if (task1()) {
		task3();
	}
	return 0;
}